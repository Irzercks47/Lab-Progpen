<footer>
    Copyright &copy; <?= date("Y") ?> QueueForum
</footer>