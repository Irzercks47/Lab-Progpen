<?php
$server = 'localhost';
$username = 'root';
$password = '';
$database = 'queueforum';
