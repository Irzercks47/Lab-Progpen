<footer>

<!-- Copyright -->
  <div class="text-center text-white p-3" style="background-color: rgba(0, 0, 0, 1);">
    Made by <b> CH21-1 </b>
  </div>
<!-- Copyright -->

</footer>